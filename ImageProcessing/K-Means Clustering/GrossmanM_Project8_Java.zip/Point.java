public class Point {
    public int label;
    public double distance;
    public double x;
    public double y;
    public Point(Double X, Double Y){
        label = 0;
        x = X;
        y = Y;
    }
    public void plot(int[][] array){

    }
    

}
